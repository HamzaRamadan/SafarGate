// 'use client';

// import React, { createContext, useContext, useMemo, useState, useEffect, type ReactNode } from 'react';
// import { type FirebaseApp } from 'firebase/app';
// import { type Firestore } from 'firebase/firestore';
// import { type Functions } from 'firebase/functions';
// import { type Auth, type User, onAuthStateChanged } from 'firebase/auth';
// import { FirebaseErrorListener } from '@/components/FirebaseErrorListener'

// interface FirebaseProviderProps {
//   children: ReactNode;
//   firebaseApp: FirebaseApp;
//   firestore: Firestore;
//   auth: Auth;
//   functions: Functions;
// }

// // Internal state for user authentication
// interface UserAuthState {
//   user: User | null;
//   isUserLoading: boolean;
//   userError: Error | null;
// }

// // Combined state for the Firebase context
// export interface FirebaseContextState {
//   areServicesAvailable: boolean; // True if core services (app, firestore, auth instance) are provided
//   firebaseApp: FirebaseApp | null;
//   firestore: Firestore | null;
//   auth: Auth | null; // The Auth service instance
//   functions: Functions | null;
//   // User authentication state
//   user: User | null;
//   isUserLoading: boolean; // True during initial auth check
//   userError: Error | null; // Error from auth listener
// }

// // Return type for useFirebase()
// export interface FirebaseServicesAndUser {
//   firebaseApp: FirebaseApp;
//   firestore: Firestore;
//   auth: Auth;
//   functions: Functions;
//   user: User | null;
//   isUserLoading: boolean;
//   userError: Error | null;
// }

// // Return type for useUser() - specific to user auth state
// export interface UserHookResult {
//   user: User | null;
//   isUserLoading: boolean;
//   userError: Error | null;
// }

// // React Context
// export const FirebaseContext = createContext<FirebaseContextState | undefined>(undefined);

// /**
//  * FirebaseProvider manages and provides Firebase services and user authentication state.
//  */
// export const FirebaseProvider: React.FC<FirebaseProviderProps> = ({
//   children,
//   firebaseApp,
//   firestore,
//   auth,
//   functions,
// }) => {
//   const [userAuthState, setUserAuthState] = useState<UserAuthState>({
//     user: null,
//     isUserLoading: true, // Start loading until first auth event
//     userError: null,
//   });

//   // Effect to subscribe to Firebase auth state changes
//   useEffect(() => {
//     if (!auth) { // If no Auth service instance, cannot determine user state
//       setUserAuthState({ user: null, isUserLoading: false, userError: new Error("Auth service not provided.") });
//       return;
//     }

//     setUserAuthState({ user: null, isUserLoading: true, userError: null }); // Reset on auth instance change

//     const unsubscribe = onAuthStateChanged(
//       auth,
//       (firebaseUser) => { // Auth state determined
//         setUserAuthState({ user: firebaseUser, isUserLoading: false, userError: null });
//       },
//       (error) => { // Auth listener error
//         setUserAuthState({ user: null, isUserLoading: false, userError: error });
//       }
//     );
//     return () => unsubscribe(); // Cleanup
//   }, [auth]); // Depends on the auth instance

//   // Memoize the context value
//   const contextValue = useMemo((): FirebaseContextState => {
//     const servicesAvailable = !!(firebaseApp && firestore && auth && functions);
//     return {
//       areServicesAvailable: servicesAvailable,
//       firebaseApp: servicesAvailable ? firebaseApp : null,
//       firestore: servicesAvailable ? firestore : null,
//       auth: servicesAvailable ? auth : null,
//       functions: servicesAvailable ? functions : null,
//       user: userAuthState.user,
//       isUserLoading: userAuthState.isUserLoading,
//       userError: userAuthState.userError,
//     };
//   }, [firebaseApp, firestore, auth, functions, userAuthState]);

//   return (
//     <FirebaseContext.Provider value={contextValue}>
//       <FirebaseErrorListener />
//       {children}
//     </FirebaseContext.Provider>
//   );
// };

// /**
//  * Hook to access core Firebase services and user authentication state.
//  * Throws error if core services are not available or used outside provider.
//  */
// export const useFirebase = (): FirebaseServicesAndUser => {
//   const context = useContext(FirebaseContext);

//   if (context === undefined) {
//     throw new Error('useFirebase must be used within a FirebaseProvider.');
//   }

//   if (!context.areServicesAvailable || !context.firebaseApp || !context.firestore || !context.auth || !context.functions) {
//     throw new Error('Firebase core services not available. Check FirebaseProvider props.');
//   }

//   return {
//     firebaseApp: context.firebaseApp,
//     firestore: context.firestore,
//     auth: context.auth,
//     functions: context.functions,
//     user: context.user,
//     isUserLoading: context.isUserLoading,
//     userError: context.userError,
//   };
// };

// /** Hook to access Firebase Auth instance. */
// export const useAuth = (): Auth => {
//   const { auth } = useFirebase();
//   return auth;
// };

// /** Hook to access Firestore instance. */
// export const useFirestore = (): Firestore => {
//   const { firestore } = useFirebase();
//   return firestore;
// };

// /** Hook to access Firebase App instance. */
// export const useFirebaseApp = (): FirebaseApp => {
//   const { firebaseApp } = useFirebase();
//   return firebaseApp;
// };

// /**
//  * Hook specifically for accessing the authenticated user's state.
//  * This provides the User object, loading status, and any auth errors.
//  * @returns {UserHookResult} Object with user, isUserLoading, userError.
//  */
// export const useUser = (): UserHookResult => {
//   const { user, isUserLoading, userError } = useFirebase(); // Leverages the main hook
//   return { user, isUserLoading, userError };
// };




'use client';

import React, { createContext, useContext, useMemo, useState, useEffect, type ReactNode } from 'react';
import { type FirebaseApp } from 'firebase/app';
import { type Firestore } from 'firebase/firestore';
import { type Functions } from 'firebase/functions';
import { type Auth, type User, onAuthStateChanged } from 'firebase/auth';
import { type FirebaseStorage } from 'firebase/storage'; // ✅ أضف هذا
import { FirebaseErrorListener } from '@/components/FirebaseErrorListener'

interface FirebaseProviderProps {
  children: ReactNode;
  firebaseApp: FirebaseApp;
  firestore: Firestore;
  auth: Auth;
  functions: Functions;
  storage: FirebaseStorage; // ✅ أضف هذا
}

// Internal state for user authentication
interface UserAuthState {
  user: User | null;
  isUserLoading: boolean;
  userError: Error | null;
}

// Combined state for the Firebase context
export interface FirebaseContextState {
  areServicesAvailable: boolean;
  firebaseApp: FirebaseApp | null;
  firestore: Firestore | null;
  auth: Auth | null;
  functions: Functions | null;
  storage: FirebaseStorage | null; // ✅ أضف هذا
  user: User | null;
  isUserLoading: boolean;
  userError: Error | null;
}

// Return type for useFirebase()
export interface FirebaseServicesAndUser {
  firebaseApp: FirebaseApp;
  firestore: Firestore;
  auth: Auth;
  functions: Functions;
  storage: FirebaseStorage; // ✅ أضف هذا
  user: User | null;
  isUserLoading: boolean;
  userError: Error | null;
}

// Return type for useUser()
export interface UserHookResult {
  user: User | null;
  isUserLoading: boolean;
  userError: Error | null;
}

// React Context
export const FirebaseContext = createContext<FirebaseContextState | undefined>(undefined);

/**
 * FirebaseProvider manages and provides Firebase services and user authentication state.
 */
export const FirebaseProvider: React.FC<FirebaseProviderProps> = ({
  children,
  firebaseApp,
  firestore,
  auth,
  functions,
  storage, // ✅ أضف هذا
}) => {
  const [userAuthState, setUserAuthState] = useState<UserAuthState>({
    user: null,
    isUserLoading: true,
    userError: null,
  });

  // Effect to subscribe to Firebase auth state changes
  useEffect(() => {
    if (!auth) {
      setUserAuthState({ user: null, isUserLoading: false, userError: new Error("Auth service not provided.") });
      return;
    }

    setUserAuthState({ user: null, isUserLoading: true, userError: null });

    const unsubscribe = onAuthStateChanged(
      auth,
      (firebaseUser) => {
        setUserAuthState({ user: firebaseUser, isUserLoading: false, userError: null });
      },
      (error) => {
        setUserAuthState({ user: null, isUserLoading: false, userError: error });
      }
    );
    return () => unsubscribe();
  }, [auth]);

  // Memoize the context value
  const contextValue = useMemo((): FirebaseContextState => {
    const servicesAvailable = !!(firebaseApp && firestore && auth && functions && storage); // ✅ أضف storage
    return {
      areServicesAvailable: servicesAvailable,
      firebaseApp: servicesAvailable ? firebaseApp : null,
      firestore: servicesAvailable ? firestore : null,
      auth: servicesAvailable ? auth : null,
      functions: servicesAvailable ? functions : null,
      storage: servicesAvailable ? storage : null, // ✅ أضف هذا
      user: userAuthState.user,
      isUserLoading: userAuthState.isUserLoading,
      userError: userAuthState.userError,
    };
  }, [firebaseApp, firestore, auth, functions, storage, userAuthState]); // ✅ أضف storage في dependencies

  return (
    <FirebaseContext.Provider value={contextValue}>
      <FirebaseErrorListener />
      {children}
    </FirebaseContext.Provider>
  );
};

/**
 * Hook to access core Firebase services and user authentication state.
 */
export const useFirebase = (): FirebaseServicesAndUser => {
  const context = useContext(FirebaseContext);

  if (context === undefined) {
    throw new Error('useFirebase must be used within a FirebaseProvider.');
  }

  if (!context.areServicesAvailable || !context.firebaseApp || !context.firestore || !context.auth || !context.functions || !context.storage) { // ✅ أضف storage
    throw new Error('Firebase core services not available. Check FirebaseProvider props.');
  }

  return {
    firebaseApp: context.firebaseApp,
    firestore: context.firestore,
    auth: context.auth,
    functions: context.functions,
    storage: context.storage, // ✅ أضف هذا
    user: context.user,
    isUserLoading: context.isUserLoading,
    userError: context.userError,
  };
};

/** Hook to access Firebase Auth instance. */
export const useAuth = (): Auth => {
  const { auth } = useFirebase();
  return auth;
};

/** Hook to access Firestore instance. */
export const useFirestore = (): Firestore => {
  const { firestore } = useFirebase();
  return firestore;
};

/** Hook to access Firebase App instance. */
export const useFirebaseApp = (): FirebaseApp => {
  const { firebaseApp } = useFirebase();
  return firebaseApp;
};

/** Hook to access Functions instance. */ // ✅ أضف هذا
export const useFunctions = (): Functions => {
  const { functions } = useFirebase();
  return functions;
};

/** Hook to access Storage instance. */ // ✅ أضف هذا
export const useStorage = (): FirebaseStorage => {
  const { storage } = useFirebase();
  return storage;
};

/**
 * Hook specifically for accessing the authenticated user's state.
 */
export const useUser = (): UserHookResult => {
  const { user, isUserLoading, userError } = useFirebase();
  return { user, isUserLoading, userError };
};
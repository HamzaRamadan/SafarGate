# وثيقة الهندسة الفنية: شجرة المصادقة والتسجيل الموحدة (ARTA-002)

هذا المستند هو المرجع السيادي الرسمي للبنية الفنية والهيكلية لعملية الدخول والتسجيل الموحدة لجميع الأدوار (مسافر وناقل) في نظام "سفريات"، بالإضافة إلى بوابة الدخول المحصنة للمشرف.

---

### شجرة الرسم التقني (Technical Architecture Tree)

هذا الرسم يوضح المسار الموحد الذي يسلكه المستخدم منذ لحظة وصوله للنظام.

```
/ (نقطة الدخول الأولى) -> [src/app/page.tsx]
│
├── 🔘 **اختيار الدور (مسافر / ناقل)**
│   │   // توجيه بصري فقط، لا يؤثر على المنطق
│   └── ➡️ REDIRECT TO -> /login
│
└── 🚪 **بوابة الدخول الموحدة** -> [src/app/login/page.tsx]
    │
    ├── ✨ **ميزة جانبية (Side Feature):**
    │   └── 📥 **عرض نافذة تثبيت التطبيق (PWA Install Prompt)**
    │
    ├── 📱 **إدخال رقم الهاتف**
    │   └── 🔎 LOGIC: calls checkUserExistence(phoneNumber) -> [src/lib/simple-auth.ts]
    │
    ├── 🤔 **هل الرقم موجود؟**
    │   │
    │   ├── ✅ **نعم (مستخدم عائد):**
    │   │   ├── 1. Fetches user document.
    │   │   ├── 2. Reads 'role' field.
    │   │   └── 3. [توجيه ذكي]:
    │   │       ├── role='carrier'  -> REDIRECT TO /carrier
    │   │       └── role='traveler' -> REDIRECT TO /dashboard
    │   │
    │   └── ❌ **لا (مستخدم جديد):**
    │       ├── 1. Show registration form (الاسم، تحديد الدور).
    │       ├── 2. LOGIC: calls registerNewUser(...) -> [src/lib/simple-auth.ts]
    │       ├── 3. Creates new user document in Firestore.
    │       └── 4. [توجيه ذكي]:
    │           ├── role='carrier'  -> REDIRECT TO /carrier (with Toast alert)
    │           └── role='traveler' -> REDIRECT TO /dashboard
    │
    └── 🛡️ **قلعة المشرف (Admin Citadel) - [مسار منفصل]**
        │
        └── 🔐 **تسجيل الدخول (Login)** -> [src/app/admin/login/page.tsx]
            └── المنطق:
                ├── 1. calls signInWithEmail()
                └── 2. [تحقق مزدوج]: Fetches user doc and validates role is 'admin' or 'owner'.

---

### الملفات السيادية المتحكمة بالعملية

*   **`src/lib/simple-auth.ts`**:
    *   **الوظيفة:** هو العقل المدبر الموحد لعملية الدخول. يحتوي على الدوال الأساسية:
        *   `checkUserExistence`: للبحث عن المستخدم في قاعدة البيانات عبر الهاتف.
        *   `registerNewUser`: لإنشاء ملف مستخدم جديد لمستخدمي الهاتف.
        *   `initiateEmailSignUp` & `signInWithEmail`: لتسجيل ودخول مستخدمي البريد الإلكتروني (المشرفين).
        *   `initiateGoogleSignIn`: لتسجيل الدخول عبر جوجل.

*   **`src/app/login/page.tsx`**:
    *   **الوظيفة:** هي نقطة التفاعل الوحيدة للمستخدم العادي (مسافر/ناقل).

*   **`firestore.rules`**:
    *   **الوظيفة:** يعمل كحارس أمني لقاعدة البيانات.

*   **`src/hooks/use-user-profile.ts`**:
    *   **الوظيفة:** يقوم بجلب ملف تعريف المستخدم بعد تسجيل الدخول.


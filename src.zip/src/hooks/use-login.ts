'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { checkUserExistence, registerNewUser } from '@/lib/simple-auth';
import { useToast } from '@/hooks/use-toast';
import { useAuth, useFirestore } from '@/firebase';
import type { UserProfile } from '@/lib/data';
import { signInAnonymously } from 'firebase/auth';

export function useLogin() {
  const router = useRouter();
  const { toast } = useToast();
  const auth = useAuth();
  const db = useFirestore();

  const [step, setStep] = useState<'phone' | 'name' | 'authenticate'>('phone');
  const [loading, setLoading] = useState(false);
  // P-16: Strict typing applied
  const [returningUser, setReturningUser] = useState<Partial<UserProfile> | null>(null);
  
  const [formData, setFormData] = useState({
    phone: '',
    firstName: '',
    role: 'carrier' as 'carrier' | 'traveler',
    agreed: false,
  });

  const handleCheckPhone = async () => {
    if (!formData.phone || formData.phone.length < 9 || !db) return;
    setLoading(true);
    const checkResult = await checkUserExistence(db, formData.phone);
    setLoading(false);

    if (checkResult.exists) {
      setReturningUser(checkResult.data as UserProfile);
      setStep('authenticate');
      toast({ title: "أهلاً بعودتك", description: `مرحباً ${checkResult.data.firstName}` });
    } else {
      setStep('name');
    }
  };

  const handleRegister = async () => {
    if (!formData.agreed) {
      toast({ variant: "destructive", title: "يجب الموافقة على الشروط" });
      return;
    }
    if (!db || !auth) return;
    setLoading(true);

    const result = await registerNewUser(db, auth, formData.phone, formData.firstName, formData.role);

    if (result.success) {
      toast({ title: "تم التسجيل", description: "جاري الدخول..." });
      // P-13: Soft Navigation
      router.push(formData.role === 'carrier' ? '/carrier' : '/dashboard');
    } else {
      toast({ variant: "destructive", title: "فشل التسجيل" });
      setLoading(false);
    }
  };

  const handleReturningUserLogin = async () => {
      if (!returningUser?.role || !auth) return;
      setLoading(true);
      try {
          if (!auth.currentUser) {
            await signInAnonymously(auth);
          }
          toast({ title: "تم تسجيل الدخول", description: `أهلاً بعودتك ${returningUser.firstName}`});
          // P-13: Soft Navigation
          router.push(returningUser.role === 'carrier' ? '/carrier' : '/dashboard');
      } catch (e) {
          toast({variant: "destructive", title: "فشل الدخول"});
          setLoading(false);
      }
  };

  const resetToPhoneStep = () => {
    setStep('phone');
    setReturningUser(null);
  };

  return {
    step,
    loading,
    returningUser,
    formData,
    setFormData,
    handleCheckPhone,
    handleRegister,
    handleReturningUserLogin,
    resetToPhoneStep,
  };
}

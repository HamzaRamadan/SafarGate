'use client';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Ship, User, Loader2 } from 'lucide-react';
import InstallPrompt from '@/components/install-prompt';
import { useLogin } from '@/hooks/use-login';

export default function LoginPage() {
  const {
    step,
    loading,
    returningUser,
    formData,
    setFormData,
    handleCheckPhone,
    handleRegister,
    handleReturningUserLogin,
    resetToPhoneStep,
  } = useLogin();

  return (
    <div className="flex min-h-screen flex-col items-center justify-center p-4 bg-background" dir="rtl">
      <div className="w-full max-w-md space-y-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold tracking-tight">نظام سفريات</h2>
          <p className="text-muted-foreground mt-2">بوابة الدخول الموحدة</p>
        </div>

        <div className="space-y-6 bg-card p-6 rounded-xl border shadow-sm">
           <InstallPrompt />
           
          {step === 'phone' && (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>رقم الهاتف</Label>
                <Input 
                   type="tel" 
                   placeholder="079xxxxxxx" 
                   value={formData.phone}
                  onChange={(e) => setFormData({...formData, phone: e.target.value})}
                  className="text-left ltr"
                  disabled={loading}
                />
              </div>
              <Button className="w-full" onClick={handleCheckPhone} disabled={loading || formData.phone.length < 9}>
                {loading ? <Loader2 className="animate-spin" /> : 'التالي'}
              </Button>
            </div>
          )}

          {step === 'name' && (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>الاسم الرباعي</Label>
                <Input 
                   placeholder="الاسم الكامل" 
                   value={formData.firstName}
                  onChange={(e) => setFormData({...formData, firstName: e.target.value})}
                  disabled={loading}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div onClick={() => !loading && setFormData({...formData, role: 'carrier'})} className={`cursor-pointer border rounded-lg p-4 text-center flex flex-col items-center gap-2 ${formData.role === 'carrier' ? 'bg-primary/10 border-primary' : ''}`}>
                  <Ship className="h-8 w-8 text-primary" />
                  <span className="font-bold">ناقل</span>
                </div>
                <div onClick={() => !loading && setFormData({...formData, role: 'traveler'})} className={`cursor-pointer border rounded-lg p-4 text-center flex flex-col items-center gap-2 ${formData.role === 'traveler' ? 'bg-primary/10 border-primary' : ''}`}>
                  <User className="h-8 w-8 text-primary" />
                  <span className="font-bold">مسافر</span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <Checkbox id="terms" checked={formData.agreed} onCheckedChange={(c) => setFormData({...formData, agreed: c as boolean})} disabled={loading} />
                <Label htmlFor="terms">أوافق على الشروط والأحكام</Label>
              </div>

              <Button className="w-full" onClick={handleRegister} disabled={loading || !formData.agreed || !formData.firstName}>
                {loading ? <Loader2 className="animate-spin" /> : 'تسجيل ودخول'}
              </Button>
            </div>
          )}

          {step === 'authenticate' && returningUser && (
            <div className="space-y-6 text-center animate-in fade-in">
               <div className="mx-auto w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
                  <User className="h-8 w-8 text-primary" />
               </div>
               <h3 className="text-xl font-bold">مرحباً بعودتك، {returningUser.firstName}</h3>
                <p className="text-muted-foreground text-sm">
                  تم التعرف على حسابك كـ "{returningUser.role === 'carrier' ? 'ناقل' : 'مسافر'}".
                </p>
               <Button className="w-full" onClick={handleReturningUserLogin} disabled={loading}>
                 {loading ? <Loader2 className="animate-spin" /> : 'دخول إلى حسابي'}
               </Button>
               <Button variant="outline" className="w-full" onClick={resetToPhoneStep} disabled={loading}>
                 استخدام رقم آخر
               </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

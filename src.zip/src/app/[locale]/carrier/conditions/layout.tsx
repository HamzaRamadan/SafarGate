'use client';
import { type ReactNode } from "react";

export default function CarrierConditionsLayout({ children }: { children: ReactNode }) {
    return (
        <>
            {children}
        </>
    )
}

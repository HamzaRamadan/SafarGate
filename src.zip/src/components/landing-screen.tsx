'use client';

import Link from 'next/link';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { MapPinned, ArrowLeft, Bus, Shield } from 'lucide-react';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { Logo } from '@/components/logo';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/firebase';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

export default function LandingScreen() {
  const bgImage = PlaceHolderImages.find((img) => img.id === 'login-background');
  
  const router = useRouter();
  const auth = useAuth();
  const [showAdminModal, setShowAdminModal] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogoClick = () => {
    setShowAdminModal(true);
  };

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth) {
        setError('خدمة المصادقة غير متاحة.');
        return;
    }
    try {
      await signInWithEmailAndPassword(auth, email, password);
      setShowAdminModal(false);
      router.push('/admin'); 
    } catch (err) {
      setError('بيانات الاعتماد غير صحيحة، تم تفعيل بروتوكول الرفض.');
    }
  };

  return (
    <>
      <div className="relative flex min-h-screen w-full flex-col items-center justify-center p-4 overflow-hidden" dir="rtl">
        
        {bgImage && (
          <Image
            src={bgImage.imageUrl}
            alt="Safar Gate Background"
            fill
            className="absolute inset-0 -z-10 h-full w-full object-cover opacity-90"
            priority
          />
        )}
        <div className="absolute inset-0 -z-10 bg-black/60 backdrop-blur-[2px]" />

        <div className="w-full max-w-5xl z-10 flex flex-col items-center gap-6 animate-in fade-in slide-in-from-bottom-4 duration-700">
          
          <div className="text-center space-y-4 mb-4">
              {/* --- بداية التعديل الجراحي --- */}
              <div onClick={handleLogoClick} className="flex justify-center">
                  <div className="cursor-pointer hover:scale-110 transition-transform duration-300">
                    <Logo />
                  </div>
              </div>
              {/* --- نهاية التعديل الجراحي --- */}
              <h1 className="text-4xl md:text-6xl font-black text-white tracking-tight drop-shadow-lg">
                بوابتك للسفر البري
              </h1>
              <p className="text-lg text-gray-200 max-w-lg mx-auto leading-relaxed">
                المنصة الأولى لربط المسافرين بأفضل شركات النقل والسائقين المحترفين بكل أمان وموثوقية.
              </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full max-w-3xl mt-2 px-4">
            
            <Card className="group relative overflow-hidden border-white/10 bg-white/5 hover:bg-white/10 transition-all duration-300 cursor-pointer backdrop-blur-md shadow-2xl hover:shadow-primary/20 hover:border-primary/30">
              <CardHeader>
                <CardTitle className="flex items-center gap-3 text-white text-2xl">
                  <MapPinned className="h-8 w-8 text-primary group-hover:scale-110 transition-transform" />
                  مسافر
                </CardTitle>
                <CardDescription className="text-gray-300 text-base">
                  أبحث عن رحلة آمنة ومريحة لوجهتي
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Link href="/login?role=traveler" className="absolute inset-0 z-20">
                  <span className="sr-only">دخول كمسافر</span>
                </Link>
                <Button className="w-full gap-2 bg-primary hover:bg-primary/90 text-primary-foreground text-lg h-12 group-hover:translate-x-1 transition-transform">
                  حجز رحلة جديدة <ArrowLeft className="h-5 w-5" />
                </Button>
              </CardContent>
            </Card>

            <Card className="group relative overflow-hidden border-white/10 bg-white/5 hover:bg-white/10 transition-all duration-300 cursor-pointer backdrop-blur-md shadow-2xl hover:shadow-amber-500/20 hover:border-amber-500/30">
              <CardHeader>
                <CardTitle className="flex items-center gap-3 text-white text-2xl">
                  <Bus className="h-8 w-8 text-amber-500 group-hover:scale-110 transition-transform" />
                  ناقل / سائق
                </CardTitle>
                <CardDescription className="text-gray-300 text-base">
                  أملك مركبة وأبحث عن ركاب
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Link href="/login?role=carrier" className="absolute inset-0 z-20">
                   <span className="sr-only">دخول كناقل</span>
                </Link>
                <Button variant="outline" className="w-full gap-2 border-amber-500 text-amber-500 hover:bg-amber-500 hover:text-white text-lg h-12 group-hover:translate-x-1 transition-transform bg-transparent">
                  تسجيل رحلاتي <ArrowLeft className="h-5 w-5" />
                </Button>
              </CardContent>
            </Card>

          </div>
          
          <div className="text-xs text-gray-500 mt-8 font-mono">
            © 2026 جميع الحقوق محفوظة لمنصة سفريات
          </div>

        </div>
      </div>
      
      {/* --- نافذة البوابة السرية (Modal) --- */}
      <Dialog open={showAdminModal} onOpenChange={setShowAdminModal}>
        <DialogContent className="sm:max-w-md bg-card border-primary">
          <form onSubmit={handleAdminLogin}>
              <DialogHeader>
                  <DialogTitle className="flex items-center gap-2"><Shield className="h-6 w-6 text-primary"/> بوابة القيادة</DialogTitle>
                  <DialogDescription>
                      للمخولين فقط. سيتم تسجيل جميع محاولات الدخول.
                  </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                  {error && <p className="text-red-500 text-sm text-center">{error}</p>}
                  <div className="space-y-2">
                      <Label htmlFor="email-secret" className="text-right">
                          البريد الإلكتروني
                      </Label>
                      <Input
                          id="email-secret"
                          type="email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          required
                          dir="ltr"
                      />
                  </div>
                  <div className="space-y-2">
                      <Label htmlFor="password-secret" className="text-right">
                          كلمة المرور
                      </Label>
                      <Input
                          id="password-secret"
                          type="password"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          required
                          dir="ltr"
                      />
                  </div>
              </div>
              <DialogFooter>
                  <Button type="button" variant="secondary" onClick={() => setShowAdminModal(false)}>إلغاء</Button>
                  <Button type="submit">دخول</Button>
              </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
}
